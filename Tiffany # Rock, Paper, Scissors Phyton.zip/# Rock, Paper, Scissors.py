import tkinter as tk
from random import choice

def play(user_choice):
    options = ["Rock", "Paper", "Scissors"]
    computer_choice = choice(options)
    if user_choice == computer_choice:
        result_label.config(text=f"Tie! Both chose {user_choice}", fg="orange")
    elif (user_choice == "Rock" and computer_choice == "Scissors") or \
         (user_choice == "Paper" and computer_choice == "Rock") or \
         (user_choice == "Scissors" and computer_choice == "Paper"):
        result_label.config(text=f"You Win! {user_choice} beats {computer_choice}", fg="green")
    else:
        result_label.config(text=f"You Lose! {computer_choice} beats {user_choice}", fg="red")

app = tk.Tk()
app.title("Rock, Paper, Scissors")
app.geometry("300x300")
app.configure(bg="lightpink")  # Light pink background

tk.Label(app, text="Choose your move:", bg="lightpink", fg="black", font=("Arial", 14)).pack(pady=10)

button_frame = tk.Frame(app, bg="lightpink")
button_frame.pack()

rock_button = tk.Button(button_frame, text="Rock", command=lambda: play("Rock"), bg="blue", fg="white")
rock_button.grid(row=0, column=0, padx=10, pady=10)

paper_button = tk.Button(button_frame, text="Paper", command=lambda: play("Paper"), bg="green", fg="white")
paper_button.grid(row=0, column=1, padx=10, pady=10)

scissors_button = tk.Button(button_frame, text="Scissors", command=lambda: play("Scissors"), bg="red", fg="white")
scissors_button.grid(row=0, column=2, padx=10, pady=10)

result_label = tk.Label(app, text="", bg="lightpink", fg="black", font=("Arial", 14))
result_label.pack(pady=20)

app.mainloop()
